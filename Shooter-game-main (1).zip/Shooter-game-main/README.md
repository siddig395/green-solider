# Shooter Game and Level Editor

## Overview

The **Shooter Game** is a 2D game where the user controls a solider that fights through levels to clear them, using the items in the enviroment to help them eliminate enemies. 
**Level Editor** allows user to customize new levels or edit existing levels to achive different level of creativity and difficulties.

CONTROLS:
 - SPACE: shoot
 - W: jump
 - A: move left
 - D: move right
 - Q: throw grenades

## 1- Main Menu
![start_menu](https://github.com/user-attachments/assets/797ef90e-b007-4133-ba5d-58448fd46712)

## 2- Gameplay
![gameplay](https://github.com/user-attachments/assets/86ca5445-55e9-47d8-b9bc-f118c86eabcc)

## 3- Death Screen
![death_screen](https://github.com/user-attachments/assets/2b9e1f11-4338-4e64-ad12-dae451de5466)

## 4- Level Editor

![level editor](https://github.com/user-attachments/assets/bea2c118-c368-46ac-bba2-dcfbe7cf34f3)




## Requirements

- Python 3.x
- Pygame library

You can install `pygame` using pip:

```bash
pip install pygame
